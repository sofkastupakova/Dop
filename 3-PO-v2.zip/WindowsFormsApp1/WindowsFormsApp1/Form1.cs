﻿using System;
using System.Windows.Forms;

using BasicLib;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private string data = "localhost\\SQLEXPRESS";
        private string DataSource
        {
            get
            {
                return data;
            }
            set
            {
                data = value;
                Database.DataSourceLink = $"Data Source={value}; Initial catalog=ЭкоТур; Integrated Security=true";
            }
        }

        public Form1()
        {
            InitializeComponent();

            textBox5.Text = DataSource;
            label1.Visible = false;
        }

        private void Enter_btn_Click(object sender, EventArgs e)
        {//
            string login = textBox1.Text;
            string pass = textBox2.Text;
            try
            {
                if (login == "user1" || login == "user2" )
                {
                    if (login == "user1" && pass =="123")
                    {
 Form2 form = new Form2();
                    form.Show(this);
                    this.Hide();
                    }
                    if (login == "user2" && pass == "12345") {
                        Form5 form = new Form5();
                        form.Show(this);
                        this.Hide();
                    }
                    else
                    {
                        label1.Visible = true;
                    }

                }
                else
               {
                   label1.Visible = true;
               }

            }
            catch (Exception ex)
            {

            }
            
            //try
            //{
            //    var usr = User.Auth(login, pass);

            //    if (usr != null)
            //    {
            //        Form2 form = new Form2();
            //        form.Show(this);
            //        this.Hide();
            //    } else
            //    {
            //        label1.Visible = true;
            //    }
            //} catch (Exception ex){}
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form4 form = new Form4();
            form.Show(this);
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.DataSource = textBox5.Text;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
