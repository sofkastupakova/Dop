﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace BasicLib
{
    public static class Database
    {
        private static string link;
        public static string DataSourceLink
        {
            get
            {
                return link;
            }
            set
            {
                link = value;
                _sqlConnection = new SqlConnection(DataSourceLink);
            }
        }

        private static SqlConnection _sqlConnection;

        /// <summary>
        /// Возвращает одно значение
        /// </summary>
        /// <param name="query">строка запроса</param>
        public static object GetScalar(string query)
        {
            object obj = null;
            try
            {
                _sqlConnection.Open();
                SqlCommand cmd = new SqlCommand(query, _sqlConnection);
                obj = cmd.ExecuteScalar();
                _sqlConnection.Close();
                return obj;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return obj;
        }

        /// <summary>
        /// Получить массив строк
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public static List<string[]> Execute(string query)
        {
            List<string[]> result = new List<string[]>();
            try
            {
                _sqlConnection.Open();

                SqlCommand cmd = new SqlCommand(query, _sqlConnection);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    int c = reader.FieldCount;
                    List<string> temp = new List<string>();
                    for (int i = 0; i < c; i++)
                    {
                        temp.Add(reader.GetValue(i).ToString());
                    }
                    result.Add(temp.ToArray());
                }

                _sqlConnection.Close();

                return result;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return result;
        }
        /// <summary>
        /// Возвращает число затронутых строк
        /// </summary>
        /// <param name="query">строка запроса</param>
        public static int ExecuteNonQuery(string query)
        {
            int count = 0;
            try
            {
                _sqlConnection.Open();
                SqlCommand cmd = new SqlCommand(query, _sqlConnection);
                count = cmd.ExecuteNonQuery();
                _sqlConnection.Close();

                return count;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return count;
        }
    }
}
