﻿namespace BasicLib
{
    public static class AuthUser
    {
        private static User _user = null;

        public static void SetUser(User user)
        {
            _user = user;
        }

        public static User GetUser()
        {
            return _user;
        }
    }
}
