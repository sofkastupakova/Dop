﻿namespace BasicLib
{
    public class User
    {
        public string Login { get; set; }
        public string Username { get; set; }
        public int Id { get; set; }

        private User(string login, string username, int id)
        {
            Login = login;
            Username = username;
            Id = id;
        }

        public static void Register(string login, string password, string username)
        {
            string query = $"INSERT INTO Users(login, password, username) VALUES('{login}', '{password}', '{username}')";
            Database.ExecuteNonQuery(query);
        }

        public static User Auth(string login, string password)
        {
            string query = $"SELECT username, id FROM Users WHERE login='{login}' AND password='{password}'";

            var result = Database.Execute(query);

            if (result.Count > 0)
            {
                return new User(login, result[0][0], int.Parse(result[0][1]));
            }

            return null;
        }

        public static void Remove(int id)
        {
            string query = $"DELETE FROM Users WHERE id={id}";
            Database.ExecuteNonQuery(query);
        }
    }
}
