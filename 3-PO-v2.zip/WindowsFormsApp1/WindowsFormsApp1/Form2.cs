﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
      
      
        public Form2()
        {
            InitializeComponent();
            dataGridView1.Rows.Add("22.09.2022", "55°47,45′ с. ш. 49°6,87′ в. д.", "Соловьев Константин","Мишин Валерий");
            dataGridView1.Rows.Add("25.09.2022", "55°47,45′ с. ш. 49°6,87′ в. д.", "Коровьев Михаил", "Костин Кирилл");
            dataGridView1.Rows.Add("12.10.2022", "55°47,45′ с. ш. 49°6,87′ в. д.", "Соловьев Константин", "Мишин Валерий");
            listBox1.Items.Add("\n\n\n");
            listBox1.Items.Add("Заявка №1 Васильева Е.В.");
            listBox1.Items.Add("Заявка №2 Нестерова Е.В.");

            // dataGridView1.Rows.Add();
            // dataGridView1.Rows.Add();

        }
       
        private void button1_Click(object sender, EventArgs e)
        {
            Form f3 = new Form3();
            f3.ShowDialog();

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
 if (Class1.i == 0)
            {
                dataGridView1.Rows.Add(Class1.dat, Class1.coord, Class1.clname, Class1.naname);
                Class1.i = 1;
            }
            }
            catch
            {

            }
           

        }
    }
}
