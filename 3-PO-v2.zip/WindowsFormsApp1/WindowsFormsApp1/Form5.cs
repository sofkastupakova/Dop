﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
            dataGridView1.Rows.Add("22.09.2022", "55°47,45′ с. ш. 49°6,87′ в. д.", "Соловьев Константин", "Мишин Валерий");
           
            dataGridView1.Rows.Add("12.10.2022", "55°47,45′ с. ш. 49°6,87′ в. д.", "Соловьев Константин", "Мишин Валерий");

        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
    }
}
