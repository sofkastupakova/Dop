﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public static class Class1
    {
        public static string dat;
        public static string coord;
        public static string clname;
        public static string naname;
        public static int i;

        static void Dat(string dat1)
        {
            dat = dat1;
        }
        static string Dat1(string dat1)
        {
            return dat;
        }
        static void Coord(string dat1)
        {
            coord = dat1;
        }
        static string Coord1(string dat1)
        {
            return coord;
        }
        static void Clname(string dat1)
        {
            clname = dat1;
        }
        static string Clname1(string dat1)
        {
            return clname;
        }
        static void Naname(string dat1)
        {
            naname = dat1;
        }
        static string Naname1(string dat1)
        {
            return naname;
        }
    }
}
