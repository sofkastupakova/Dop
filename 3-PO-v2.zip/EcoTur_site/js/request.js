const form = document.getElementById('form');

form.onsubmit = function submitHandler(e) {
    e.preventDefault();
    alert("Ваша заявка отправлена.")

    const inputs = document.getElementsByClassName("request_form__input");

    for (let input of inputs) {
        input.value = "";
    }

    document.getElementById("textarea").value = "";
};